<?php date_default_timezone_set('America/Los_Angeles'); ?>
<div class="push"></div>
    </div>



    <div class="footer">
  <p style="text-align:center;font-size:8pt;">
    &#169;<?php echo date('Y'); ?> <a style="color: blue" href="http://codologic.com">Codologic.com</a> 
    - <a  style="color: blue" href="license.txt" target="_blank">Terms & Conditions</a>
</p>
    </div>
</body>
</html>