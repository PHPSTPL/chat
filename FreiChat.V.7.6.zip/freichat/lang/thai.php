<?php
//FreiChatX - English language
//English is the primary language
//cb->chatbox
//g->guest
//Do not use space but nbsp;
//If you have copied this file and you are making your own
//language then please write in the format similar to
//english_informal.php

    $frei_trans['cb_head']           =          'ÊÁÒªÔ¡';
    $frei_trans['g_prefix']          =          'ºØ€€Å·ÑèÇä»-';
    $frei_trans['pwdby']             =          'ÊÃéÒ§âŽÂ';
    $frei_trans['noline']            =          'äÁèÁÕŒÙéÍÍ¹äÅ¹ì';
    $frei_trans['noperms']           =          '¡ÃØ³ÒÅçÍ€ÍÔ¹!';
    $frei_trans['on_offline']        =          '¡ÓÅÑ§¹Óà¢éÒÃÒÂª×èÍŒÙéãªé<br/>Querying DataBase<br/>..............................';
    $frei_trans['go_online']         =          'ÍÍ¹äÅ¹ì';
    $frei_trans['go_offline']        =          'ÍÍ¿äÅ¹ì';
    $frei_trans['go_invisible']      =          'äÁè»ÃÒ¡¯';
    $frei_trans['go_busy']           =          'äÁèÇèÒ§';
    $frei_trans['newmesg']           =          'ÁÕ¢éÍ€ÇÒÁãËÁè! šÒ¡';
    $frei_trans['restore_drag_pos']  =          '¡ÅÑºÊÙèµÓáË¹è§àŽÔÁ';
    $frei_trans['status_txt']        =          'à»ÅÕèÂ¹Ê¶Ò¹Ð';
    $frei_trans['opt_txt']           =          'ÍÍ¿ªÑè¹àÊÃÔÁ';
    $frei_trans['onOfflinemesg']     =          'ÍÍ¹äÅ¹ìáªµ!';

    $frei_trans['plugin_transdisable']  =       '»ÔŽ¡ÒÃãªé§Ò¹';
    $frei_trans['plugin_trans_orig']    =       '¢éÍ€ÇÒÁµé¹©ºÑº:';

    $frei_trans['titles_translate']     =       'á»ÅÀÒÉÒ';
    $frei_trans['titles_upload']        =       'Êè§ä¿Åì';

    $frei_trans['status_online']        =       'ÍÍ¹äÅ¹ì';
    $frei_trans['status_busy']          =       'äÁèÇèÒ§';
    $frei_trans['status_invisible']     =       'äÁè»ÃÒ¡¯';
    $frei_trans['status_offline']       =       'ÍÍ¿äÅ¹ì';

         return 1;
?>
